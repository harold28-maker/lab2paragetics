# LAB2 Veterinaria - Starter

Proyecto base para trabajar el Laboratorio 2 de Gestión de Servicios TICS.

## Qué contiene
- Spring Boot
- Spring MVC
- Thymeleaf
- Spring Data JPA
- MySQL Driver
- Estructura de Entity / Repository / Controller / Views
- TODOs organizados por P1 a P6
- Archivo `git-steps.txt` con la secuencia de ramas del laboratorio

## Importante
El enunciado no muestra el `CREATE TABLE` ni los tipos/nombres exactos de la tabla de mascotas.
Antes de ejecutar contra la BD debes revisar:

1. `@Table(name = "...")`
2. nombres de columnas
3. tipos Java
4. si la PK es AUTO_INCREMENT o no
5. URL, usuario y contraseña de MySQL

## Ejecutar
1. Editar `src/main/resources/application.properties`
2. Desde la raíz:

```bash
mvn spring-boot:run
```

3. Cuando hayas implementado P2, abrir:

```text
http://localhost:8080/mascotas
```

## Conceptos que debes aplicar siguiendo la PPT
- P3: Query Methods
- P5: @Query + @Modifying + @Transactional
- P6: @Query para consultas personalizadas
