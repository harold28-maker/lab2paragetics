package com.example.lab2veterinaria.repository;

import com.example.lab2veterinaria.entity.Mascota;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface MascotaRepository extends JpaRepository<Mascota, Integer> {

    /*
     * TODO P3 - Query Methods
     * La PPT muestra el patrón:
     *   findByAtributo...
     * y ejemplos como ContainingIgnoreCase.
     *
     * Completa tú los métodos para:
     * - nombre
     * - especie
     * - estado
     *
     * Ejemplo de forma (NO es la respuesta final del lab):
     * List<Mascota> findByNombreContainingIgnoreCase(String texto);
     */

    /*
     * TODO P5 - Consulta personalizada de actualización
     * Según la PPT, para UPDATE personalizado debes usar:
     * @Transactional
     * @Modifying(clearAutomatically = true)
     * @Query(...)
     *
     * Completa la consulta usando los atributos Java reales de Mascota.
     */

    /*
     * TODO P6 - Reporte
     * Implementa consultas personalizadas para:
     * - edad máxima
     * - edad mínima
     * - edad promedio
     * - cantidad total
     *
     * La PPT explica @Query y @Param, pero el laboratorio pide que
     * estas métricas salgan de consultas personalizadas.
     */
}
