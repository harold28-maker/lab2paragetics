package com.example.lab2veterinaria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab2VeterinariaApplication {

    public static void main(String[] args) {
        SpringApplication.run(Lab2VeterinariaApplication.class, args);
    }
}
