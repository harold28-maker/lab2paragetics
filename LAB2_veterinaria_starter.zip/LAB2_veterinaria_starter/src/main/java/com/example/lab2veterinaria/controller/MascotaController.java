package com.example.lab2veterinaria.controller;

import com.example.lab2veterinaria.repository.MascotaRepository;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/mascotas")
public class MascotaController {

    private final MascotaRepository mascotaRepository;

    public MascotaController(MascotaRepository mascotaRepository) {
        this.mascotaRepository = mascotaRepository;
    }

    /*
     * TODO P2:
     * GET /mascotas
     * - obtener el listado
     * - enviarlo por Model
     * - retornar mascotas/lista
     */

    /*
     * TODO P3:
     * Implementa búsqueda con:
     * - texto
     * - criterio (nombre, especie o estado)
     * - Query Methods del repositorio
     * - opción para limpiar filtros y volver al listado
     */

    /*
     * TODO P4:
     * - GET para mostrar formulario de nueva mascota
     * - POST para registrar
     * - redirect al listado
     */

    /*
     * TODO P5:
     * - GET para cargar la mascota actual con findById
     * - POST para actualizar usando la consulta personalizada del repositorio
     * - NO reemplazar por save() para la parte evaluada de actualización
     */

    /*
     * TODO P6:
     * - GET para reporte
     * - enviar al Model: max, min, promedio, total
     */
}
