package com.example.lab2.repository;

import com.example.lab2.entity.Employee;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepository extends JpaRepository<Employee, Integer> {
    // TODO LAB P3:
    // No agregues Query Methods ni @Query; el enunciado los prohíbe.
}
