package com.example.lab2.controller;

import com.example.lab2.repository.EmployeeRepository;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/employees")
public class EmployeeController {

    private final EmployeeRepository employeeRepository;

    public EmployeeController(EmployeeRepository employeeRepository) {
        this.employeeRepository = employeeRepository;
    }

    @GetMapping
    public String listar(Model model) {
        // TODO LAB P2:
        // 1) Usa employeeRepository.findAll()
        // 2) Envía el resultado al Model
        // 3) Retorna la vista employees
        model.addAttribute("mensaje", "Completa la lógica de listado indicada en el LAB.");
        return "employees";
    }

    // TODO LAB P2: GET /employees/ver?id=...
    // TODO LAB P3: GET /employees/buscar con parámetros opcionales
    // TODO LAB P4: GET del formulario + POST /employees/guardar con Data Binding
    // TODO LAB P5: GET /employees/editar?id=... y actualización con save()
}
