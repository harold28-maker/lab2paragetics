package com.example.lab2.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

@Entity
@Table(name = "employees")
public class Employee {

    @Id
    private Integer employeeId;

    // TODO LAB P1:
    // Agrega y mapea aquí los demás campos de employees exactamente como aparecen en el enunciado:
    // first_name, last_name, email, phone_number, hire_date, job_id, salary,
    // commission_pct, manager_id, department_id.
    //
    // Usa @Column(name = "...") cuando el nombre Java y el nombre SQL sean distintos.
    // Agrega constructor vacío, getters y setters.

    public Employee() {
    }

    public Integer getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(Integer employeeId) {
        this.employeeId = employeeId;
    }
}
