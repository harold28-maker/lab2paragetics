# LAB2 GTICS 2026-2 - Starter

Este proyecto es un esqueleto ejecutable para que completes el laboratorio siguiendo el enunciado.

## Requisitos
- Java 17
- Maven
- MySQL
- Base de datos `hr` ya creada con el script entregado por el curso

## Configuración
Edita:
`src/main/resources/application.properties`

Cambia:
- `spring.datasource.username`
- `spring.datasource.password`

## Ejecutar
En la carpeta del proyecto:

```bash
mvn spring-boot:run
```

Luego abre:
`http://localhost:8080/employees`

## Orden de ramas sugerido por el LAB
- develop
- feature/entity
- feature/list
- feature/search
- feature/register
- feature/edit

## Nota
Los TODO marcan las partes evaluadas que debes implementar tú.
